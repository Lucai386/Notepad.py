# icone reperite da : https://www.flaticon.com
# codice scritto da Luca Arnone
'''
    notepad.py is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    notepad.py is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with notepad.py.  If not, see <http://www.gnu.org/licenses/>.
'''
import tkinter as tk
from tkinter import ttk
from tkinter import font, colorchooser, filedialog, messagebox
import os

principale = tk.Tk()
principale.geometry("800x600")
principale.title("Appunti")

menu_princiaple = tk.Menu()

#Icone file
nuovo_icona = tk.PhotoImage(file = "Ide/icone/new.png")
apri_icona = tk.PhotoImage(file = "Ide/icone/folder.png")
salva_icona = tk.PhotoImage(file = "Ide/icone/save.png")
salvaConNome_icona = tk.PhotoImage(file = "Ide/icone/save_as.png")
esci_incona = tk.PhotoImage(file = "Ide/icone/logout.png")

#Icone modifiche
copia_icona = tk.PhotoImage(file = "Ide/icone/copy.png")
incolla_icona = tk.PhotoImage(file = "Ide/icone/sheet.png")
taglia_icona = tk.PhotoImage(file = "Ide/icone/cut.png")
pulisci_icona = tk.PhotoImage(file = "Ide/icone/eraser.png")
cerca_icona = tk.PhotoImage(file = "Ide/icone/search.png")

#Icone Vedi
strumenti_icona = tk.PhotoImage(file = "Ide/icone/hammer.png")
status_icona = tk.PhotoImage(file = "Ide/icone/doc-file.png")

file = tk.Menu(menu_princiaple, tearoff = False)
modifiche = tk.Menu(menu_princiaple, tearoff = False)
vedi = tk.Menu(menu_princiaple, tearoff = False)

menu_princiaple.add_cascade(label = "File", menu = file)
menu_princiaple.add_cascade(label = "Modifiche", menu = modifiche)
menu_princiaple.add_cascade(label = "Vedi", menu = vedi)


#File

percorso = ""
def fun_nuovo(event = None):
    global percorso
    percorso = ""
    text_editor.delete(1.0, tk.END)

file.add_command(label = "Nuovo ", image = nuovo_icona, compound = tk.LEFT, accelerator = "Ctrl+n", command = fun_nuovo)

def fun_apri(event = None):
    global percorso
    percorso = ""
    percorso = filedialog.askopenfilename(initialdir = os.getcwd(), title = "seleziona file", filetypes = (("Text file", "*.txt"), ("All files", "*.*")))
    try:
        with open (percorso, "r" ) as lettura:
            text_editor.delete(1.0, tk.END)
            text_editor.insert(1.0, lettura.read())
    except FileNotFoundError:
        return
    except:
        return
    principale.title(os.path.basename(percorso))
    
file.add_command(label = "Apri", image = apri_icona, compound = tk.LEFT, accelerator = "Ctrl+o", command = fun_apri)

def fun_salva(event = None):
    global percorso
    try:
        if percorso:
            contenuto = str(text_editor.get(1.0, tk.END))
            with open(percorso, "w", encoding= "utf-8") as lettura:
                lettura.write(contenuto)
        else:
            percorso = filedialog.asksaveasfile(mode = "w", defaultextension =".txt", filetypes = (("Text file", "*.txt"), ("All files", "*.*")))
            contenuto2 = text_editor.get(1.0, tk.END)
            percorso.write(contenuto2)
            percorso.close()

    except:
        return
file.add_command(label = "Salva", image = salva_icona, compound = tk.LEFT, accelerator = "Ctrl+s", command = fun_salva)

def fun_salvaConNome(event = None):
    global percorso
    try:
        percorso = filedialog.asksaveasfile(mode = "w", defaultextension =".txt", filetypes = (("Text file", "*.txt"), ("All files", "*.*")))
        contenuto = text_editor.get(1.0, tk.END)
        percorso.write(contenuto)
        percorso.close()
    except:
        return

file.add_command(label = "Salva con nome", image = salvaConNome_icona, compound = tk.LEFT, accelerator = "Ctrl+Alt+s", command = fun_salvaConNome)

def fun_esci(event = None):
    global cambia_testo, percorso
    try:
        if cambia_testo:
            mbox = messagebox.askokcancel("Attenzione", "Vuoi salvare questo file prima di uscire?")
            if mbox is True:
                if percorso:
                    contenuto = text_editor.get(1.0, tk.END)
                    with open(percorso, "w", encoding="utf-8") as lettura:
                        lettura.write(contenuto)
                        principale.destroy()
                else:
                    percorso = filedialog.asksaveasfile(mode = "w", defaultextension =".txt", filetypes = (("Text file", "*.txt"), ("All files", "*.*")))
                    contenuto = text_editor.get(1.0, tk.END)
                    percorso.write(contenuto)
                    principale.destroy()
            elif mbox is False:
                principale.destroy()
        else:
            principale.destroy()        
    except:
        return


file.add_command(label = "Esci", image = esci_incona, compound = tk.LEFT, accelerator = "Ctrl+", command = fun_esci)


#Modifiche
modifiche.add_command(label = "Copia", image = copia_icona, compound = tk.LEFT, accelerator = "Ctrl+c", command = lambda:text_editor.event_generate("<Control c>"))
modifiche.add_command(label = "Incolla", image = incolla_icona, compound = tk.LEFT, accelerator = "Ctrl+v", command = lambda:text_editor.event_generate("<Control v>"))
modifiche.add_command(label = "Taglia", image = taglia_icona, compound = tk.LEFT, accelerator = "Ctrl+x", command = lambda:text_editor.event_generate("<Control x>"))
modifiche.add_command(label = "Pulisci", image = pulisci_icona, compound = tk.LEFT, accelerator = "Ctrl+Alt+x", command = lambda:text_editor.delete(1.0, tk.END))

def fun_cerca(event = None):
    def fun_ricercaParola():
        parola = ricerca_input.get()
        text_editor.tag_remove("match", "1.0", tk.END)
        confronti = 0
        
        if parola:
            posizione_iniziale = "1.0"
            while True:
                posizione_iniziale = text_editor.search(parola, posizione_iniziale, stopindex = tk.END)
                if not posizione_iniziale:
                    break
                posizione_finale = f"{posizione_iniziale}+{len(parola)}c"
                text_editor.tag_add("match",posizione_iniziale,posizione_finale)
                confronti += 1
                posizione_iniziale = posizione_finale
                text_editor.tag_config("match", foreground = "red", background = "blue")

    def fun_sostituzione(event = None):
        parola =  ricerca_input.get()
        sostituzione = sostituzione_input.get()
        contenuto = text_editor.get(1.0, tk.END)      
        nuovo_contenuto = contenuto.replace(parola, sostituzione) 
        text_editor.delete(1.0, tk.END) 
        text_editor.insert(1.0, nuovo_contenuto)
        print(ricerca_input)

    finestra_ricerca = tk.Toplevel()
    finestra_ricerca.geometry("400x200")
    finestra_ricerca.title("Ricerca e sostituzione")
    finestra_ricerca.resizable(0,0)

    ricerca_frame = ttk.Label(finestra_ricerca, text = "")
    ricerca_frame.pack(pady = 20)

    ricerca_testo = ttk.Label(ricerca_frame, text = "Cerca")
    sostituzione_testo = ttk.Label(ricerca_frame, text = "Sostituisci")

    ricerca_input = ttk.Entry(ricerca_frame, width = 30)
    sostituzione_input = ttk.Entry(ricerca_frame, width = 30)

    btn_ricerca = ttk.Button(ricerca_frame, text = "Cerca", command = fun_ricercaParola)
    btn_sostituzione = ttk.Button(ricerca_frame, text = "Sostituisci", command = fun_sostituzione)

    ricerca_testo.grid(row = 0, column = 0, padx = 4, pady = 4)
    sostituzione_testo.grid(row = 1, column = 0, padx = 4, pady = 4)

    ricerca_input.grid(row = 0, column = 1, padx = 4, pady = 4)
    sostituzione_input.grid(row = 1, column = 1, padx = 4, pady = 4)

    btn_ricerca.grid(row = 2, column = 0, padx = 4, pady = 4)
    btn_sostituzione.grid(row = 2, column = 1, padx = 4, pady = 4)

modifiche.add_command(label = "Cerca", image = cerca_icona, compound = tk.LEFT, accelerator = "Ctrl+f", command = fun_cerca)

#Vedi

#visibilità barra e status

vedi_statusBar = tk.BooleanVar()
vedi_statusBar.set(True)
vedi_strumenti = tk.BooleanVar()
vedi_strumenti.set(True)

def fun_strumenti(event = None):
    global vedi_strumenti
    if vedi_strumenti:
        strumenti_barra.pack_forget()
        vedi_strumenti = False
    else:
        text_editor.pack_forget()
        status_barre.pack_forget()
        strumenti_barra.pack(side = tk.TOP, fill = tk.X)
        text_editor.pack(fill = tk.BOTH, expand = True)
        status_barre.pack(side = tk.BOTTOM)
        vedi_strumenti = True


vedi.add_command(label = "Strumenti", image = strumenti_icona, compound = tk.LEFT, command = fun_strumenti)

def fun_status(event = None):
    global vedi_statusBar
    if vedi_statusBar:
        status_barre.pack_forget()
        vedi_statusBar = False
    else:
        text_editor.pack_forget()
        status_barre.pack_forget()
        strumenti_barra.pack(side = tk.TOP, fill = tk.X)
        text_editor.pack(fill = tk.BOTH, expand = True)
        status_barre.pack(side = tk.BOTTOM)
        vedi_statusBar = True

vedi.add_command(label = "Status", image = status_icona, compound = tk.LEFT, command = fun_status)


strumenti_barra = ttk.Label(principale)
strumenti_barra.pack(side = tk.TOP, fill = tk.X) 
font_tuple = tk.font.families()
font_family = tk.StringVar()

font_box = ttk.Combobox(strumenti_barra, widt = 30, textvariable = font_family, state= "readonly")
font_box["values"] = font_tuple
font_box.current(font_tuple.index('Ubuntu Mono'))
font_box.grid(row = 0, column = 0, padx = 5, pady = 5)

#Dimensioni contenitori

dimensione_interi = tk.IntVar()
dimensione_font = ttk.Combobox(strumenti_barra, width = 20, textvariable = dimensione_interi, state ="readonly")
dimensione_font["values"] = tuple(range(8, 100, 2))
dimensione_font.current(4)
dimensione_font.grid(row = 0, column = 1, padx = 5, pady = 5)

#Grassetto

grassetto_icona = tk.PhotoImage(file = "Ide/icone/bold.png")
btn_grassetto = ttk.Button(strumenti_barra, image = grassetto_icona)
btn_grassetto.grid(row = 0, column = 2, padx = 5)

#Corsivo

corsivo_icona = tk.PhotoImage(file = "Ide/icone/corsivo.png")
btn_corsivo = ttk.Button(strumenti_barra, image = corsivo_icona)
btn_corsivo.grid(row = 0, column = 3, padx = 5)

#Sottolineato

sottolineato_icona = tk.PhotoImage(file = "Ide/icone/underline.png")
btn_sottolineato = ttk.Button(strumenti_barra, image = sottolineato_icona)
btn_sottolineato.grid(row = 0, column = 4, padx = 5)

#Colore font

coloreFont_icona = tk.PhotoImage(file = "Ide/icone/colore_font.png")
btn_coloreFont = ttk.Button(strumenti_barra, image = coloreFont_icona)
btn_coloreFont.grid(row = 0, column = 5, padx = 5)

#Alineamento sinistra

sinistra_icona = tk.PhotoImage(file = "Ide/icone/align-left.png")
btn_sinistra = ttk.Button(strumenti_barra, image = sinistra_icona)
btn_sinistra.grid(row = 0, column = 6, padx = 5)

#Alineamento centro

centro_icona = tk.PhotoImage(file = "Ide/icone/align.png")
btn_centro = ttk.Button(strumenti_barra, image = centro_icona)
btn_centro.grid(row = 0, column = 7, padx = 5)

#Alineamento destra

destra_icona = tk.PhotoImage(file = "Ide/icone/align-right.png")
btn_destra = ttk.Button(strumenti_barra, image = destra_icona)
btn_destra.grid(row = 0, column = 8, padx = 5)

#Testo e scrollbar

text_editor = tk.Text(principale)
text_editor.config(wrap = "word", relief = tk.FLAT)

scroll_bar = tk.Scrollbar(principale)
text_editor.focus_set()
scroll_bar.pack(side = tk.RIGHT, fill = tk.Y)
text_editor.pack(fill = tk.BOTH, expand = True)
scroll_bar.config(command = text_editor.yview)
text_editor.config(yscrollcommand = scroll_bar.set)

# Funzioni e font

font_inizio = "Ubuntu Mono"
font_dimensione_inizio = 16

def cambia_font(principale):
    global font_inizio
    font_inizio = font_family.get()
    text_editor.configure(font = (font_inizio, font_dimensione_inizio))

def cambia_dimensione_font(principale):
    global font_dimensione_inizio
    font_dimensione_inizio = dimensione_interi.get()
    text_editor.configure(font = (font_inizio, font_dimensione_inizio))


font_box.bind("<<ComboboxSelected>>", cambia_font)
dimensione_font.bind("<<ComboboxSelected>>", cambia_dimensione_font)

#Grassetto, corsivo e sottolineato + funzioni colore, ed allineamenti

def fun_grassetto():
    ottieni_font = tk.font.Font(font = text_editor["font"])
    if ottieni_font.actual()["weight"] == 'normal':
        text_editor.configure(font = (font_inizio, font_dimensione_inizio, "bold"))
    elif ottieni_font.actual()["weight"] == 'bold':
        text_editor.configure(font = (font_inizio, font_dimensione_inizio, "normal"))

btn_grassetto.configure(command = fun_grassetto)

def fun_corsivo():
    ottieni_font = tk.font.Font(font = text_editor["font"])
    if ottieni_font.actual()["slant"] == 'roman':
        text_editor.configure(font = (font_inizio, font_dimensione_inizio, "italic"))
    elif ottieni_font.actual()["slant"] == 'italic':
        text_editor.configure(font = (font_inizio, font_dimensione_inizio, "roman"))

btn_corsivo.configure(command = fun_corsivo)

def fun_sottolineato():
    ottieni_font = tk.font.Font(font = text_editor["font"])
    if ottieni_font.actual()["underline"] == 0:
        text_editor.configure(font = (font_inizio, font_dimensione_inizio, "underline"))
    elif ottieni_font.actual()["underline"] == 1:
        text_editor.configure(font = (font_inizio, font_dimensione_inizio, "normal"))

btn_sottolineato.configure(command = fun_sottolineato)

def fun_colore():
    colore = tk.colorchooser.askcolor()
    text_editor.configure(fg = colore[1])

btn_coloreFont.configure(command = fun_colore)

def fun_sinistra():
    posizione_testo = text_editor.get(1.0, "end")
    text_editor.tag_config("left", justify = tk.LEFT)
    text_editor.delete(1.0, tk.END)
    text_editor.insert(tk.INSERT, posizione_testo, "left")

btn_sinistra.configure(command = fun_sinistra)

def fun_centro():
    posizione_testo = text_editor.get(1.0, "end")
    text_editor.tag_config("center", justify = tk.CENTER)
    text_editor.delete(1.0, tk.END)
    text_editor.insert(tk.INSERT, posizione_testo, "center")

btn_centro.configure(command = fun_centro)

def fun_destra():
    posizione_testo = text_editor.get(1.0, "end")
    text_editor.tag_config("right", justify = tk.RIGHT)
    text_editor.delete(1.0, tk.END)
    text_editor.insert(tk.INSERT, posizione_testo, "right")

btn_destra.configure(command = fun_destra)

# contaggio caratteri e parole

status_barre = ttk.Label(principale, text = "Status")
status_barre.pack(side = tk.BOTTOM)

cambia_testo = False

def contatore (event = None):
    global cambia_testo
    if text_editor.edit_modified():
        cambia_testo = True
        parole = len(text_editor.get(1.0, "end-1c").split())
        caratteri = len(text_editor.get(1.0, "end-1c").replace(" ", ""))
        status_barre.config(text = f"caratteri : {caratteri} parole {parole}")
    text_editor.edit_modified(False)

text_editor.bind("<<Modified>>", contatore)


principale.config(menu = menu_princiaple)

principale.mainloop()